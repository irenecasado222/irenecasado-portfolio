document.getElementById('menu').addEventListener('click', function()
{

document.getElementById('navega').classList.toggle('mostrar');


});


function reproducir(){
document.getElementById('miVideo').play();

}


function pausar(){
    document.getElementById('miVideo').pause();


}