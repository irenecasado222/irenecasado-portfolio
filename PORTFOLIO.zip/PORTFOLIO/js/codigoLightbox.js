lightbox.option({
  'wrapAround': true,
  'albumLabel':"Imagen %1 de %2",
  'fadeDuration':1000,
 
})
